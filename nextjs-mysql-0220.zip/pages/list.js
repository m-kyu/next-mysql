import axios from 'axios';
import Link from 'next/link';
import React, { useEffect, useReducer, useState } from 'react'



const List = () => {
   

  const [data,setData] = useState([]);

  async function axiosTrans(type,num){
    let d;
    d = await axios.get('/api').then(res=>res.data); 
    setData(d)
  }

  async function del(id){
    let d;
    d = await axios.delete(`/api/${id}`).then(res=>res.data); 
    setData(d)
  }

  useEffect(()=>{
    axiosTrans('select');    
  },[])

  if(!data.length) return(<>loading...</>)
    
  return (
    <div>
        <h2>List
          <Link href="/write"> write </Link>
        </h2>        

        {
            data.map((res)=>(
                <p key={res.id}>{res.name} 
                  <Link href={{pathname:'/update',query:res}} >수정</Link>
                  <button onClick={()=>del(res.id)}>삭제</button>
                </p>
            ))
        }
    </div>
  )
}

export default List